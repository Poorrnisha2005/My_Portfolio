const fs = require("fs")
    //fs.writeFile("sample.txt", "created a new file using fs", (err) => {})

//fs.appendFile("sample.txt", "\nAppended a file ", () => {})
// fs.readFile("sample.txt", (err, data) => {
//     console.log(data.toString())
// })
// fs.unlink("sample.txt",()=>{})

    //fs.writeFile("sample.txt","created a file usinf fs",(err)=>{})
        // try {
        //     const data = fs.readFileSync('sample.tt', 'utf8'); // Read the file synchronously
        //     console.log(data); // Output the file content
        // } catch (err) {
        //     console.error("Error reading file:", err.message); // Handle the error
        // }


        // fs.mkdir("folder",(err)=>{});
        // fs.rmdir("folder",(err)=>{});

    // fs.readFile("sample.txt","utf-8",(err,data)=>{
    //     console.log(data)
    // })

    const fileData=fs.readFileSync("sample.txt","utf-8")
    console.log(fileData);
    console.log("outside");

fs.writeFile("first.txt",fileData,(err)=>{})