const mongoose = require('mongoose')

async function DB(){
    try{
        await mongoose.connect('mongodb://localhost:27017/course')
        console.log("Connected to DB")
    }
    catch(error){
        console.log("Error connecting to DB")
    }   
}

module.exports = DB