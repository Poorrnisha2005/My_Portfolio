const express = require("express")
const app = express()
const DB = require("./db/db")
const courseSchema = require("./models/schema")
const cors = require ("cors")
app.use(cors())

app.get("/api/v1/search",async (req,res)=>{
       await DB() 
      // const course =  await courseSchema.find()
  
       let  query = req.query.search
       console.log(req.query);
       let course = await courseSchema.find({title:{$regex:query,$options:"i"}})
       console.log(course);
       
       res.json(course)
       
       
})

app.listen(3000,()=>{
    console.log("server is running");   
})