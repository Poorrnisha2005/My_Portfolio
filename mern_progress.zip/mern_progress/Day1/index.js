var data="value";
data=1
data=true
data=[1,2,3,4]
data={key:1}
console.log(data);

// single line command
/* 
multiline commands
*/

var itsString="            hello theree         ";
console.log(typeof itsString);
console.log(itsString.length);
console.log(itsString.split(""));
console.log(itsString.trim());
itsString=itsString.trim()
console.log(itsString.length);
console.log(itsString.lastIndexOf('l'));
console.log("str"+"1");
var newVar=123;
console.log(newVar.toString());
console.log(typeof ""+newVar);
console.log( typeof `${newVar}`);

var newVar1=`jhgefimlmlkfm
nfhdkkmf,sef
jnfkjnenldijiehd   ${newVar}`
console.log(newVar1);

var numHolder=123.45

var strHolder="123"
console.log(typeof Number(strHolder));
console.log(typeof +strHolder);


var intValue=123.4
console.log(Math.round(intValue));
console.log(Math.ceil(intValue));
console.log(Math.floor(intValue));

console.log(Math.pow)

console.log(Math.min(3894,3121));
console.log(Math.max(536783,3435));

console.log(Math.random()*100);

console.log(Number.parseInt(Math.random()*100));

console.log(Math.abs(-123));

console.log(Math.sqrt(9));

var booleanVar=false;
console.log(booleanVar);


//  undefined

var dataType;
console.log(dataType);

//  NULL 

var dataType=null;
console.log(dataType);


//  array

var arrayVariable=[1,35,32,"jeifje",{obj:1}]

console.log(arrayVariable)

arrayVariable.push(3);

console.log(arrayVariable);

console.log(arrayVariable.pop());

// to add an element in zeroth index

arrayVariable.shift(43);
console.log(arrayVariable);




// Assessment

var reve="HELLO";
reve=reve.split("");
reve=reve.reverse();
reve=reve.join("");
console.log(reve);


// iteration

//for(declaration,condition,increment/decrement)

for(var i=0;i<5;i++)
    console.log(i);


for(var i=5;i>0;i++)
    console.log(i)


// while

var i=0;
while(i<5){
    console.log(i);
    i++;
}


while(i>0){
    console.log(i);
    i--;
}


do{
    console.log("hello");
}while(false)

fruits=["apple","orange","pineapple","mango"].forEach((i,k)=>{
    console.log(k,i);
})



// conditional statement

if(true){
    console.log("block printed");
}


if(false){
    console.log("block printed");
}




var i=10

if(i==2){
    console.log("block 1 passed");
}

else if(i==3)
{
    console.log("block 2 passed");
}

else if(i==10){
    console.log("yes"+10);
    
}

else{
    console.log("nothing caught");
}


var character= 'r';
if(character=='a'||character=='e'||character=='i'||character=='o'||character=='u')
    console.log("vowel");
else
    console.log("consonant");
    
    


// switch 

switch(true){
    case character=='a':
        console.log("yes");
    break;
    case character=='e':
        console.log("yes");
    break;
    case character=='i':
        console.log("yes");
    break;
    case character=='o':
        console.log("yes");
    break;
    case character=='u':
        console.log("yes");
    break;
    default:
        console.log("no");
}


// or


switch(true){
    case character=='a':
    case character=='e':
    case character=='i':
    case character=='o':
    case character=='u':
    console.log("yes");
    break;
    default:
        console.log("no");
}



//getting values from the user

var chara= prompt("Enter the value : ")

// for getting input from user we give prompt if not to display alert message we give alert in the place of prompt



function sayhello(){
    console.log("Helllooo there");
}

sayhello();



function multiple(value)
{
    console.log(value*value);
    
}
var answer=multiple(2);
console.log(answer);


const arrSum=(arr) => {
    var sum=0;
    for(var i=0;i<arr.length;i++)
    {
        sum=sum+arr[i];
    }
    console.log(sum);
    
}
