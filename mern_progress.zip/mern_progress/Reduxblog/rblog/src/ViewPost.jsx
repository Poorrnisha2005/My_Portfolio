import "./App.css";
import React from 'react'
import { useSelector } from 'react-redux'
import { useDispatch } from 'react-redux'
function ViewPost() {
    const selector = useSelector((state) => state.post)
    console.log(selector)
  return (
    <div className="view-post-container">
  {selector.map((i, index) => {
    return (
      <div className="post-card" key={index}>
        <p>{i.author}</p>
        <p>{i.data}</p>
      </div>
    );
  })}
</div>

  )
}

export default ViewPost