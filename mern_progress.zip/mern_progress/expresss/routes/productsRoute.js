const express = require('express')
const { getProducts, getProductById, createProduct, updateProduct, deleteProduct } = require("../routeHandler/productFunction");
const productRoutes = express.Router()
productRoutes.route("/").get(getProducts).post(createProduct)
productRoutes.route("/").get(getProductById).patch(updateProduct).put(updateProduct).delete(deleteProduct)

module.exports = productRoutes;