const express = require('express');
const morgan = require("morgan")
const app = express();
const productRoutes = require("./routes/productsRoute")
app.use(express.json());
app.use(morgan("dev"))

// app.get("/*",(req,res)=>{
//     res.json({
//         status:"error",
//         message:"Page not found"
//     })
// })

app.use("/api/v1/products", productRoutes)

module.exports = app