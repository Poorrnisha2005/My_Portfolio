// // //getElementByid
// // //getElementsbyCallName
// // //getElementByTagName
// // //querySelector
// // //querySelectorAll

// // // let h1 = document.getElementById("tag1")
// // // console.log(h1);

// // //text manipulation

// // //  h1.innerHTML="hello there"
// // // h1.innerText = "hello"

// // // location.assign("google.com")
// // // console.log(screen.orientation);
// // // history;

// // // let div = document.createElement("div")
// // //     //div.innerText = "created using js";
// // // let textNode = document.createTextNode("created using js")
// // // console.log(div);
// // // Create a new div element
// // // let div = document.createElement("div");

// // // // Create a text node and append it to the div
// // // let textnode = document.createTextNode("created using js");
// // // div.append(textnode);

// // // // Assign multiple classes to the div
// // // div.classList.add("divClass", "class2", "class3");

// // // // Get the element with id "data" (make sure this element exists in the HTML)
// // // let body = document.getElementById("data");

// // // // Append the created div to the "data" element
// // // body.append(div);
// // // let list = document.querySelector("ul li")
// // // console.log(list)

// // // let list = document.getElementByClass("one")[4]
// // // console.log(list);



// // let body = document.getElementById("data")
// // let ul = document.createElement("ul");
// // let li1 = document.createElement("li");
// // let li2 = document.createElement("li");
// // let li3 = document.createElement("li");
// // let li4 = document.createElement("li");
// // let li5 = document.createElement("li");
// // let li6 = document.createElement("li");
// // ul.append(li1, li2, li3, li4, li5, li6)
// // console.log(ul)
// // let text = document.createTextNode("onion")
// // let text1 = document.createTextNode("orange")
// // let text2 = document.createTextNode("apple")
// // let text3 = document.createTextNode("mango")
// // let text4 = document.createTextNode("banana")
// // let text5 = document.createTextNode("strawberry");

// // li1.append(text)
// // li2.append(text1)
// // li3.append(text2)
// // li4.append(text3)
// // li5.append(text4)
// // li6.append(text5)

// // body.append(ul)
// //     // ul.className = "divClass";
// //     // ul.setAttribute("id", "tag")
// //     // ul.style.color = "purple";
// //     // ul.style.backgroundColor = "lavender";

// // ul.style.cssText = `color:teal`;
// // let body = document.getElementById("data")
// // let fruits = ["apple", "orange", "pineapple", "mango"]
// // let ul = document.createElement("ul")
// // fruits.map((i) => {
// //     let li = document.createElement("li")
// //     let tN = document.createTextNode(i);
// //     li.append(tN);
// //     ul.append(li);
// // })

// // document.body.append(ul)
// // 
// // let body = document.getElementById("data")
// // body.children[0].remove()

// // let li = document.getElementById("one")
// // li.remove()


// let date = new Date();
// console.log(date.getDate());
// console.log(date.getHours());
// console.log(date.getMinutes());
// console.log(date.getSeconds());


// let button=document.getElementById("button")
// button.addEventListener("click",()=>{
//     alert("you clicked a button");
// })

// let parent=document.getElementsByClassName("div1")[0]
// let child1=document.getElementsByClassName("div2")[0]
//  let child2=document.getElementsByClassName("div3")[0]


// parent.addEventListener("click",()=>{
//     alert("you clicked the parent");
// })


// child1.addEventListener("click",()=>{
//     alert("you clicked the child1");
// })

// const event1=(e)=>{
//     console.log(e.target.tagName);
//     remove()
// }
// child2.addEventListener("click",event1)
//  const remove=()=>{
//        child2.removeEventListener("click",event1)
//  }


// const catchKeyboard=(e)=>{
//     console.log(e.key);
// }


// window.addEventListener("keyup",catchKeyboard)