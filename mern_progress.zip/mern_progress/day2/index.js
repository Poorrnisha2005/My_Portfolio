// let takeTicket=new Promise((resolve,reject)=>{
//     if(true){
//         resolve("yes booked")
//     }
//     else{
//         reject("not yet")
//     }
// })
  
// takeTicket.then((e)=>{ 
//     console.log(e);
// }).catch((err)=>{
    
// })

// let text1=document













