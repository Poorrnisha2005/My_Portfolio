import React from 'react'
import { useEffect, useState } from 'react';
import axios from "axios"
import View from './View'; 
function Task() {
    const [value,setValue] = useState("")
    const [data,setData] = useState([])
    async function getData(){
        let response =await axios.get("http://localhost:3000/api/v1/todo")
        setData(response.data)           
     }
    useEffect(()=>{
       
        getData();
    },[])
    async function handleClick(e){
        e.preventDefault();
        const res= await axios.post("http://localhost:3000/api/v1/todo",{
            task:value
        })

        setData([])
    }
  return (
    <div>
        <form>
            <label htmlFor="addtask">add task</label>
            <input value={value} onChange = {(e)=>setValue(e.target.value)}
            type="text" id= "addtask" placeholder="Enter the task"/>
            <button onClick={(e)=>handleClick(e)}>add task</button>
        </form>
        <div>
            {data.map ((i,k) => <View key = {i._id} id={i._id} handleUpdate={getData} task={i.task}/>)}
        </div>
    </div>
  )
}

export default Task