import React from "react";
import { decrement, increment, addValue } from "../../slice/counterSlice";
import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";

function Counter() {
    
    const selector = useSelector((state) => state.counter)
    console.log(selector);
    function handleClick(){
        dispatch(increment())
    }
    let uservalue = 0
    function handleClick1(){
         uservalue = Number.parseInt(prompt("Enter a number"))
         dispatch(addValue(uservalue))
    }

    const dispatch = useDispatch()
    return (
        <div>
            <div>{selector.count}</div>
            <button onClick = {handleClick1}>Add value</button>
            <button onClick = {handleClick}>INCREMENT</button>
            <button onClick = {() => dispatch(decrement())}>DECREMENT</button>
        </div>

    )
}
export default Counter