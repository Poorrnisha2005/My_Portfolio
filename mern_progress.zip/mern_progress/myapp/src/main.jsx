// import {  } from 'react'
// import { createRoot } from 'react-dom/client'
// // import './index.css'
// import App from './App.jsx'
// // import Header from './Header.jsx'
// // import Footer from './Footer.jsx'
// // import Home from './Home.jsx'
// // import About from './About.jsx'
// // import Contact from './Contact.jsx/'
// // import Content from './Content.jsx'
// // import user from './User.jsx'
// // import Components1 from './Components.jsx'
// // import Components2 from './Components.jsx'
// // import Components3 from './Components.jsx'
// // import Components4 from './Components.jsx'
// // import Components5 from './Components.jsx'
// createRoot(document.getElementById('root')).render(
//   <>
//   <App/>
//   </>
 
// )

import { createRoot } from "react-dom/client"; 
import App from "./App";
import { Provider } from "react-redux";
import store from "../reduxStore/store";
createRoot(document.getElementById('root')).render(
  <Provider store={store}>
    <App />
  </Provider>
)
