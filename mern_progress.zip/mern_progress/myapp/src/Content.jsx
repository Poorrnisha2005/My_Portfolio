// import React from 'react'

// function Content({pData}) {
//   let data="hjgfbjffvfbv b"
//   function handleclick()
//   {
//     pData(data)
//   }
//   return (
//     <div>
//       {
//         <button onclick={handleclick}>SUBMIT</button>
//       }
      
//     </div>
//   )
// }
// export default Content