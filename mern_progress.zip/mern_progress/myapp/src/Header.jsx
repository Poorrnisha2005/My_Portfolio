// // const Header=()=>{
// //     return(
// //         <div>
// //                     <div> <ul>
// //             <li>home</li>
// //             <li>products</li>
// //             <li>contact</li>
// //         </ul>
// //         </div>
// //         </div>
// //     )
// // }
// //export default Header;
// const Header=()=>{
//     //    if(true){
//     //     return(
//     //         <h1>Its for client</h1>
//     //     )
//     //    }
//     //    else{

//     //    }
//     let data=[]
//     return(
//         <>
//         {
//             // data.length>0 && 
//             // <h1>
//             //     yeahh its there
//             // </h1>
//             }
//             {data.length>=0 ?<h1> Yes there is data</h1>:<h1> no more data</h1>
//             }
//         </>
        
//     )
// }

// export default Header;



import React from 'react'

function Header() {

    function greet(greeting,symbol){
     const{name,age}=this;
     console.log(name,age)
    }

    const user={name:"jhon",age:27}

    greet.call(user,"hello","!")
  return (
    <div>
</div>
  )
}


export default Header