// import React from 'react'

// function Components1() {
//   return (
//     <div>Components1</div>
//   )
// }

// export default Components1


// //import React from 'react'

// export function Components2() {
//   return (
//     <div>Components2</div>
//   )
// }

// //export default Components2

// //import React from 'react'

// export function Components3() {
//   return (
//     <div>Components3</div>
//   )
// }

// //export default Components3


// //import React from 'react'

// export function Components4() {
//   return (
//     <div>Components4</div>
//   )
// }

// //export default Components4

// //import React from 'react'

// export function Components5() {
//   return (
//     <div>Components5</div>
//   )
// }

// //export default Components5
import React from 'react'

function Components() {
  return (
    <div>Components</div>
  )
}

export default Components