// import Header from "./Header"
// import Footer from "./Footer"
// import Content from "./Content"
// import Components1 from "./Components"
// import Components2 from "./Components"
// import Components3 from "./Components"
// import Components4 from "./Components"
// import Components5 from "./Components"
// import Oldbook from "./Oldbook"
// import NewBook from "./NewBook"
// import User from "./User"
// import { Link } from "react-router-dom"
// import { BrowserRouter,Routes,Route } from 'react-router-dom'
// import Home from "./Home"
// import About from "./About"
// import Contact from "./Contact"

// import Counter from "./counter/Counter";

// import React from "react";
// function App() {
//   return (
//     <div><Counter/></div>
//     // <>
    
//     // <BrowserRouter>
//     // <ul>
//     //   {/* <li><a href="/home">Home</a></li>
//     //   <li><a href="/about">About</a></li>
//     //   <li><a href="/contact">Contact</a></li>
//     //   <li><a href="/user">User</a></li> */}
//     //   <li><Link to="/home">Home</Link></li>
//     //   <li><Link to="/about">About</Link></li>
//     //   <li><Link to="/contact">Contact</Link></li>
//     // </ul>
//     // <Routes>
//     //   <Route path='/home' element={<Home/>}/>
//     //   <Route path='/about' element ={<About/>}/>
//     //   <Route path='/contact' element={<Contact/>}/>
//     //   <Route path='/books'>
//     //   <Route path='newbooks' element={<NewBook/>}/>
//     //   <Route path='oldbooks' element={<Oldbook/>}/>
//     //   </Route>
//     //   <Route path='/user/:id' element={<User/>}/>
      
//     //   </Routes>
//     //   </BrowserRouter>
//     // </>
//   )
// }

// export default App;

import React from 'react'

import Counter from './counter/counter'
function App() {
  return (
    <div>
    <Counter/>
    </div>

    
    
  )
}

export default App
