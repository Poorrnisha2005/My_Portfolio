// import React from 'react'
// import {useState,useRef} from 'react';

// function Footer(){
//     const refer=useRef()
//     const[data,setData]=useState(0);
//     function handleClick(){
//         refer.current.focus()
//     }
//         <div>
//            <input ref={refer}
//            type="text"/>
//            <button onClick={handleClick}>focus</button>
//         </div>
// }


// export default Footer;


