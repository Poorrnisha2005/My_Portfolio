const mongoose=require("mongoose")
const cust=require("./schema")
async function db(){
    try{
        await mongoose.connect("mongodb://localhost:27017/customer")
        console.log("database connected");
    }
    catch(e)
    {
        console.log("error in connecting the database");
    }
    // const newCustomer=new cust({
    //     name: "POORRNISHA",
    //     age:  18,
    //     address:{
    //         pincode: 629001,
    //         state: "TamilNadu"
    //     },
    //     hobbies:["Talking","Travelling","Music"]
    // })
    // console.log(customerData);
    // newCustomer.save();

const newCustomer=await cust.create({
    name: "Jeyaaa",
    age:  21,
    email: "kumarnisha702@gmail.com",
    friend: "6798615267d29a6d1ce07630",
    address:{
                pincode: 629001,
                 state: "TamilNadu"
            },
        hobbies:["Talking","Travelling","Music"]
})

// console.log(newCustomer);

// const customerData= await cust.findById(
//     "6798615267d29a6d1ce07630",{_id:0})
//     console.log(customerData);

// const customerData= await cust.find().where("name").equals("Jeyaaa").limit(1)
// console.log(customerData);

const update = await cust.updateOne({name : "Jeyaaa"},{$set:{age:30}})
console.log(update);

}
db()