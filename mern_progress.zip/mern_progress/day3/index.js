// localStorage.setItem("getBack",2500)
// console.log(localStorage.getItem("getBack"));


let val=localStorage.getItem("getCount")?
localStorage.getItem("getCount"):0
console.log(val);
localStorage.setItem("getCount",++val);