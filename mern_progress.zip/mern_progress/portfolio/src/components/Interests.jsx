import React from 'react';
// import '../Interests.css';

function Interests() {
  return (
    <section id="interests">
      <h2>Interests</h2>
      <ul>
        <li>Coding</li>
        <li>Artificial Intelligence</li>
        <li>Traveling</li>
        <li>Photography</li>
      </ul>
    </section>
  );
}

export default Interests;
