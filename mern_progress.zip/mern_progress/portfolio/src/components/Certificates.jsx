import React from 'react';
import '../index.css'; // If it's one level up


function Certificates() {
  return (
    <section id="certificates">
      <h2>Certificates</h2>
      <ul>
        <li>UDEMY: Python</li>
        <li>Great Learning: C++</li>
        <li>Coursera: C </li>
        <li>Udemy: Machine Learning</li>
        <li>Coursera: Data Science </li>
        <li>Coursera: Java</li>
      </ul>
    </section>
  );
}

export default Certificates;
